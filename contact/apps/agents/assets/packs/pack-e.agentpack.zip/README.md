# Pack E — DevOps + System Tools

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **API Load Tester Agent** (`api-load-tester-agent`) — Performs a stress test on a target URL by firing concurrent requests and measuring average latency and success rates.
- **Disk Cleanup Agent** (`disk-cleanup-agent`) — Scans a target directory and deletes files older than a specified number of days. Essential for log rotation or temp file hygiene.
- **Docker Manager Agent** (`docker-manager-agent`) — Interacts with the Docker daemon to list running containers or restart a specific container.
- **Fuzz Stress Agent (The "Chaos Monkey")** (`fuzz-stress-agent-the-chaos-monkey`) — Generates random, potentially dangerous inputs to test the robustness of a CLI command or API. It loops until it triggers a crash or timeout.
- **Git Operations Agent** (`git-operations-agent`) — Automate source control tasks. This agent can clone repositories, check status, or commit changes automatically (e.g., after a "Secret Redaction" run).
- **Port Killer Agent (DevOps Utility)** (`port-killer-agent-devops-utility`) — Finds the process ID (PID) listening on a specific TCP port and terminates it. Extremely useful when a previous server instance hangs and blocks a port.
- **Process Monitor Agent (System Control)** (`process-monitor-agent-system-control`) — Lists the top consuming processes by CPU or Memory usage. A lightweight "top" or "Task Manager" alternative.
- **Release Orchestrator Agent (The "Manager")** (`release-orchestrator-agent-the-manager`) — This agent doesn't just "do" a task; it manages a sequence of other tasks. It simulates a CI/CD pipeline by running Git checks, Tests, and Archival in order.
- **System Health Monitor** (`system-health-monitor`) — Captures a snapshot of the machine's vital signs (CPU, RAM, Uptime). Useful for creating a "Baseline Run" before executing heavy load tests.
- **Zip Archiver Agent** (`zip-archiver-agent`) — Compresses a target directory into a .zip file. Useful for backups or preparing artifacts for deployment.