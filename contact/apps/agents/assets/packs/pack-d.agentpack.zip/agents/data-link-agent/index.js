
const path = require("path");

function walkHtml(tools, dir, out){
  for(const name of tools.fs.list(dir)){
    const p = path.join(dir, name);
    let st; try{ st = tools.fs.stat(p); }catch{ continue; }
    if(st.isDirectory()) walkHtml(tools, p, out);
    else if(p.endsWith(".html")) out.push(p);
  }
}

function extractLinks(html){
  const links = [];
  const re = /(href|src)\s*=\s*["']([^"']+)["']/gi;
  let m;
  while((m=re.exec(html))){
    links.push(m[2]);
  }
  return links;
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const files=[]; walkHtml(tools, root, files);
  const broken=[];
  for(const f of files){
    const html = tools.fs.readText(f);
    for(const l of extractLinks(html)){
      if(l.startsWith("http") || l.startsWith("#") || l.startsWith("data:") || l.startsWith("mailto:")) continue;
      const target = path.resolve(path.dirname(f), l);
      try{ tools.fs.stat(target); } catch { broken.push({ file:f, link:l }); }
    }
  }
  const report = { root, html: files.length, broken: broken.length };
  tools.fs.writeText(path.join(run.dir,"artifacts","links.report.json"), JSON.stringify({ report, broken }, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/links.report.json" });
  return report;
};
