
const path = require("path");

function walk(tools, dir, out){
  for(const name of tools.fs.list(dir)){
    const p = path.join(dir, name);
    let st; try{ st = tools.fs.stat(p); }catch{ continue; }
    if(st.isDirectory()) walk(tools, p, out);
    else if(name === "index.html") out.push(p);
  }
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const out = inputs.outPath || path.join(root, "launcher.html");
  const indexes=[]; walk(tools, root, indexes);
  const items = indexes.map(p => ({ path:p, rel:path.relative(root,p).replace(/\\/g,"/") }));
  const html = `<!doctype html><meta charset="utf-8"><title>Launcher</title>
  <style>body{font-family:ui-sans-serif,system-ui;background:#0b0b12;color:#fff;padding:20px}a{color:#8ef}li{margin:8px 0}</style>
  <h1>App Launcher</h1><ul>${items.map(i=>`<li><a href="${i.rel}">${i.rel}</a></li>`).join("")}</ul>`;
  tools.fs.writeText(out, html);
  tools.fs.writeText(path.join(run.dir,"artifacts","launcher.report.json"), JSON.stringify({ root, out, count: items.length }, null, 2));
  receipts.addArtifact({ type:"file", path: path.relative(run.dir, out) });
  return { ok:true, out, count: items.length };
};
