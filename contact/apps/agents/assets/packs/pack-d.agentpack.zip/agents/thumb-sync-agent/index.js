
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const required = inputs.required ? JSON.parse(inputs.required) : ["hero.png","thumb.png","512.png"];
  const missing = [];
  for(const f of required){
    try{ tools.fs.stat(path.join(root,f)); }
    catch{ missing.push(f); }
  }
  const report = { root, required, missing };
  const outPath = path.join(run.dir,"artifacts","thumb.report.json");
  tools.fs.writeText(outPath, JSON.stringify(report, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/thumb.report.json" });
  return report;
};
