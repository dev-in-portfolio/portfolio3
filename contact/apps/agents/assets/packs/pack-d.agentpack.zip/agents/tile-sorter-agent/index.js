
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const tileFile = inputs.tileFile;
  const sortKey = inputs.sortKey || "title";
  const fix = String(inputs.fix||"").toLowerCase() === "true";
  const arr = JSON.parse(tools.fs.readText(tileFile));
  arr.sort((a,b)=> String(a?.[sortKey]||"").localeCompare(String(b?.[sortKey]||"")));
  const outPath = path.join(run.dir,"artifacts","tiles.sorted.json");
  tools.fs.writeText(outPath, JSON.stringify(arr, null, 2));
  if(fix){
    tools.fs.writeText(tileFile, JSON.stringify(arr, null, 2));
    receipts.step({ event:"tile.sort.applied", tileFile });
  }
  receipts.addArtifact({ type:"json", path:"artifacts/tiles.sorted.json" });
  return { ok:true, count: arr.length, sortKey, fix };
};
