
const path = require("path");

function walk(tools, dir, out){
  for(const name of tools.fs.list(dir)){
    const p = path.join(dir, name);
    let st;
    try{ st = tools.fs.stat(p); }catch{ continue; }
    if(st.isDirectory()) walk(tools, p, out);
    else out.push(p);
  }
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const files = [];
  walk(tools, root, files);
  const html = files.filter(f => f.endsWith(".html"));
  const report = { root, fileCount: files.length, htmlCount: html.length, sample: files.slice(0,50) };
  const outPath = path.join(run.dir,"artifacts","audit.report.json");
  tools.fs.writeText(outPath, JSON.stringify(report, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/audit.report.json" });
  return report;
};
