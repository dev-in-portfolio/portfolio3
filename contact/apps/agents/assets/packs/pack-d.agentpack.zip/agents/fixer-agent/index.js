
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const applied = [];
  // meta clean quick
  const rules = [
    { find:"Lorem ipsum", replace:"" },
    { find:"TODO:", replace:"" }
  ];
  // simple: clean index.html if present
  const idx = path.join(root,"index.html");
  try{
    let t = tools.fs.readText(idx);
    for(const r of rules){
      if(t.includes(r.find)){ t = t.split(r.find).join(r.replace); }
    }
    tools.fs.writeText(idx, t);
    applied.push("meta-clean:index.html");
  }catch{}
  // ensure 404
  const p404 = path.join(root,"404.html");
  try{ tools.fs.stat(p404); }
  catch{
    tools.fs.writeText(p404, `<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1><p>Not found.</p>`);
    applied.push("create:404.html");
  }
  const report = { root, applied };
  tools.fs.writeText(path.join(run.dir,"artifacts","fixer.report.json"), JSON.stringify(report, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/fixer.report.json" });
  return report;
};
