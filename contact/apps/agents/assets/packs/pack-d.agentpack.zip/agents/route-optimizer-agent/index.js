
const path = require("path");

function extractHrefs(html){
  const out=[];
  const re = /href\s*=\s*["']([^"']+)["']/gi;
  let m;
  while((m=re.exec(html))) out.push(m[1]);
  return out;
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const entry = inputs.entry;
  const root = inputs.root || path.dirname(entry);
  const seen = new Set();
  const edges = [];
  const missing = [];
  const queue = [entry];

  while(queue.length){
    const cur = queue.shift();
    if(seen.has(cur)) continue;
    seen.add(cur);
    let html;
    try{ html = tools.fs.readText(cur); } catch { missing.push(cur); continue; }
    for(const href of extractHrefs(html)){
      if(href.startsWith("http") || href.startsWith("#") || href.startsWith("mailto:")) continue;
      const target = path.resolve(path.dirname(cur), href);
      edges.push([cur, target]);
      if(!seen.has(target)) queue.push(target);
    }
  }

  const report = { entry, reachable: seen.size, edges: edges.length, missing: missing.length };
  tools.fs.writeText(path.join(run.dir,"artifacts","route.report.json"), JSON.stringify({ report, edges, missing }, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/route.report.json" });
  return report;
};
