
const path = require("path");

function walk(tools, dir, out){
  for(const name of tools.fs.list(dir)){
    const p = path.join(dir, name);
    let st; try{ st = tools.fs.stat(p); }catch{ continue; }
    if(st.isDirectory()) walk(tools, p, out);
    else if(name === "settings.json") out.push(p);
  }
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const fix = String(inputs.fix||"").toLowerCase()==="true";
  const source = inputs.source; // optional specific settings.json path
  const files=[]; walk(tools, root, files);
  const base = source ? JSON.parse(tools.fs.readText(source)) : (files[0] ? JSON.parse(tools.fs.readText(files[0])) : {});
  const drift=[];
  for(const f of files){
    const cur = JSON.parse(tools.fs.readText(f));
    const same = JSON.stringify(cur) === JSON.stringify(base);
    if(!same) drift.push(f);
    if(fix && !same) tools.fs.writeText(f, JSON.stringify(base, null, 2));
  }
  const report={ root, found: files.length, drift: drift.length, fixed: fix ? drift.length : 0 };
  tools.fs.writeText(path.join(run.dir,"artifacts","settings.report.json"), JSON.stringify({ report, files, drift }, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/settings.report.json" });
  return report;
};
