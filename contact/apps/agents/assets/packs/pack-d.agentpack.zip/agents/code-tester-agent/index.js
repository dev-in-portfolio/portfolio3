
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const mode = inputs.mode || "node-check";
  const report = { root, mode, checks:[] };

  if(mode === "node-check"){
    const file = inputs.file || path.join(root, "app.js");
    const r = await tools.exec({ cmd:"node", args:["--check", file], cwd: root });
    report.checks.push({ file, code:r.code, stderr:r.stderr.slice(0,2000) });
  } else if(mode === "grep"){
    const pattern = inputs.pattern || "FIXME";
    const r = await tools.exec({ cmd:"bash", args:["-lc", `grep -RIn "${pattern}" . || true`], cwd: root });
    report.checks.push({ pattern, matches: r.stdout.split("\n").filter(Boolean).slice(0,200) });
  } else {
    throw new Error("Unknown mode");
  }

  tools.fs.writeText(path.join(run.dir,"artifacts","codecheck.report.json"), JSON.stringify(report, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/codecheck.report.json" });
  return report;
};
