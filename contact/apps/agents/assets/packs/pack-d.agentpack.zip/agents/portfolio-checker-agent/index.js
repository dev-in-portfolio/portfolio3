
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const required = inputs.required ? JSON.parse(inputs.required) : ["index.html"];
  const report = { root, required, missing:[] };
  for(const f of required){
    try{ tools.fs.stat(path.join(root,f)); } catch { report.missing.push(f); }
  }
  tools.fs.writeText(path.join(run.dir,"artifacts","portfolio.report.json"), JSON.stringify(report, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/portfolio.report.json" });
  return report;
};
