
const path = require("path");

function walkHtml(tools, dir, out){
  for(const name of tools.fs.list(dir)){
    const p = path.join(dir, name);
    let st; try{ st = tools.fs.stat(p); }catch{ continue; }
    if(st.isDirectory()) walkHtml(tools, p, out);
    else if(p.endsWith(".html")) out.push(p);
  }
}

const MARK = "data-nexus-bar";
const SNIP = `<nav ${MARK} style="position:sticky;top:0;z-index:999;background:rgba(10,10,14,.9);backdrop-filter:blur(10px);padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.08);font-family:ui-sans-serif,system-ui">
  <a href="/" style="color:#fff;text-decoration:none;font-weight:700;letter-spacing:.02em">← Back to Nexus</a>
</nav>`;

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const fix = String(inputs.fix||"").toLowerCase()==="true";
  const files=[]; walkHtml(tools, root, files);
  const missing=[];
  for(const f of files){
    const t = tools.fs.readText(f);
    if(!t.includes(MARK)) missing.push(f);
  }
  const patched=[];
  if(fix){
    for(const f of missing){
      let t = tools.fs.readText(f);
      if(t.includes("<body")){
        t = t.replace(/<body[^>]*>/i, (m)=> `${m}\n${SNIP}\n`);
      } else {
        t = `${SNIP}\n` + t;
      }
      tools.fs.writeText(f, t);
      patched.push(f);
    }
  }
  const report = { root, checked: files.length, missing: missing.length, patched: patched.length };
  tools.fs.writeText(path.join(run.dir,"artifacts","nexusbar.report.json"), JSON.stringify({ report, missing, patched }, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/nexusbar.report.json" });
  return { ...report };
};
