
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const baseUrl = inputs.baseUrl || "http://localhost:8888";
  const targetKey = inputs.targetKey || "demo-form-lab";
  const urlMap = {
    "demo-form-lab": "/agents/demo-targets/form-lab/",
    "demo-crm": "/agents/demo-targets/crm/",
    "demo-job-board": "/agents/demo-targets/job-board/"
  };
  const targetUrl = urlMap[targetKey] || urlMap["demo-form-lab"];
  const steps = [
    { action:"goto", url: targetUrl },
    { action:"wait", ms: 200 },
    { action:"screenshot", label:`${targetKey}` }
  ];
  const res = await tools.browser.runFlow({ targetKey, baseUrl, flow:"smoke", steps });
  const shotsDir = path.join(run.dir, "artifacts", "screenshots");
  for(const s of res.screenshots){
    tools.fs.writeBytes(path.join(shotsDir, `${s.label}.png`), s.bytes);
  }
  receipts.addArtifact({ type:"screenshots", path:"artifacts/screenshots/" });
  return { ok:true, targetKey };
};
