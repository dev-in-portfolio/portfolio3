
const path = require("path");

function walk(tools, dir, out){
  for(const name of tools.fs.list(dir)){
    const p = path.join(dir, name);
    let st; try{ st = tools.fs.stat(p); }catch{ continue; }
    if(st.isDirectory()) walk(tools, p, out);
    else if(p.endsWith(".html") || p.endsWith(".md")) out.push(p);
  }
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const fix = String(inputs.fix||"").toLowerCase()==="true";
  const files=[]; walk(tools, root, files);
  const hits=[];
  const rules = inputs.rules ? JSON.parse(inputs.rules) : [
    { find:"Lorem ipsum", replace:"" },
    { find:"TODO:", replace:"" }
  ];

  for(const f of files){
    let t = tools.fs.readText(f);
    let changed=false;
    for(const r of rules){
      if(t.includes(r.find)){
        t = t.split(r.find).join(r.replace);
        changed=true;
      }
    }
    if(changed){
      hits.push(f);
      if(fix) tools.fs.writeText(f, t);
    }
  }
  const report = { root, files: files.length, hits: hits.length, fix };
  tools.fs.writeText(path.join(run.dir,"artifacts","metaclean.report.json"), JSON.stringify({ report, hits, rules }, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/metaclean.report.json" });
  return report;
};
