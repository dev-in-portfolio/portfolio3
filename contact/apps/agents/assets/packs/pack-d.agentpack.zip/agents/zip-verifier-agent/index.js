
const AdmZip = require("adm-zip");
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const zipPath = inputs.zipPath;
  const maxEntries = Number(inputs.maxEntries || 200);
  const z = new AdmZip(zipPath);
  const entries = z.getEntries().slice(0, maxEntries).map(e => ({ name:e.entryName, size:e.header.size }));
  const report = { zipPath, ok:true, entries: entries.length };
  tools.fs.writeText(path.join(run.dir,"artifacts","zip.report.json"), JSON.stringify({ report, entries }, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/zip.report.json" });
  return report;
};
