
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { loadVault, saveVault } = require("../../../../runner/lib/vault");

module.exports.run = async function({ inputs, tools, receipts }){
  const pass = process.env.AGENTX_VAULT_PASS || "";
  if(!pass) throw new Error("Set AGENTX_VAULT_PASS env var to use the vault.");

  const vaultPath = path.join(process.cwd(), ".agentx", "vault.enc");
  const action = inputs.action || "set"; // set|get|issue
  const key = inputs.key;

  const db = loadVault(vaultPath, pass);

  if(action === "set"){
    const value = inputs.value || "";
    db.secrets[key] = value;
    saveVault(vaultPath, pass, db);
    receipts.step({ event:"vault.set", key });
    return { ok:true, key };
  }

  if(action === "get"){
    const value = db.secrets[key];
    receipts.step({ event:"vault.get", key, found: value!=null });
    // never log value
    return { ok:true, key, found: value!=null };
  }

  if(action === "issue"){
    const value = db.secrets[key];
    if(value == null) throw new Error("No secret stored under key");
    const handle = tools.secrets.issueHandle({ value, ttlMs: Number(inputs.ttlMs||600000) });
    receipts.step({ event:"vault.issue", key, handle });
    return { ok:true, key, handle };
  }

  throw new Error("Unknown action");
};
