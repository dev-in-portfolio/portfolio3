
const path = require("path");
const fs = require("fs");
const AdmZip = require("adm-zip");

module.exports.run = async function({ inputs, tools, receipts, run }){
  // net.disabled is enforced by policy (we simply do not invoke browser tool)
  const sourceRunDir = inputs.sourceRunDir || run.dir;
  const outZip = path.join(run.dir, "artifacts", "receipts.bundle.zip");
  const z = new AdmZip();
  z.addLocalFolder(sourceRunDir);
  tools.fs.writeBytes(outZip, z.toBuffer());
  receipts.addArtifact({ type:"zip", path:"artifacts/receipts.bundle.zip" });
  receipts.step({ event:"bundle.exported", sourceRunDir });
  return { ok:true, outZip };
};
