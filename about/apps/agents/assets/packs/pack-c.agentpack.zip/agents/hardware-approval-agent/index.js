
module.exports.run = async function({ inputs, receipts }){
  // Real WebAuthn is browser-native; CLI can't do a real hardware attestation.
  // We still enforce a "user present" approval gate and record an attestation stub.
  const approved = String(inputs.approve || "").toLowerCase() === "true";
  receipts.step({ event:"hardware.authn.request", mode:"cli-stub" });
  if(!approved){
    receipts.step({ event:"hardware.authn.denied", note:"Set --approve true to simulate user-present approval." });
    return { ok:true, approved:false };
  }
  const att = { type:"cli-stub", userPresent:true, ts: Date.now() };
  receipts.step({ event:"hardware.authn.approved", attestation: att });
  return { ok:true, approved:true, attestation: att };
};
