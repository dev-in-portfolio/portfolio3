
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

function ensureDir(p){ fs.mkdirSync(p, { recursive:true }); }

module.exports.run = async function({ inputs, tools, receipts, run }){
  tools.approval.require({ level:"high", proofLabel:"sign" });
  const approved = String(inputs.approve || "").toLowerCase() === "true";
  if(!approved){
    receipts.step({ event:"sign.skipped", reason:"approval.required" });
    return { ok:true, signed:false, note:"Set --approve true to sign." };
  }

  const payloadPath = inputs.payloadPath;
  const payloadBytes = tools.fs.readBytes(payloadPath);

  const keysDir = path.join(process.cwd(), ".agentx", "keys");
  ensureDir(keysDir);
  const privPath = path.join(keysDir, "ed25519.private.pem");
  const pubPath = path.join(keysDir, "ed25519.public.pem");

  if(!fs.existsSync(privPath)){
    const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519");
    fs.writeFileSync(privPath, privateKey.export({ type:"pkcs8", format:"pem" }));
    fs.writeFileSync(pubPath, publicKey.export({ type:"spki", format:"pem" }));
    receipts.step({ event:"keys.generated", type:"ed25519" });
  }

  const privateKeyPem = fs.readFileSync(privPath, "utf8");
  const sig = tools.crypto.signEd25519({ privateKeyPem, payloadBytes });
  const sigPath = path.join(run.dir, "artifacts", path.basename(payloadPath) + ".sig");
  tools.fs.writeBytes(sigPath, sig);
  receipts.addArtifact({ type:"signature", path:`artifacts/${path.basename(payloadPath)}.sig` });
  receipts.step({ event:"signed", payloadPath });
  return { ok:true, signed:true, sigPath };
};
