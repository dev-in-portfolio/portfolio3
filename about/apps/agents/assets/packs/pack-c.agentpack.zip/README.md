# Pack C — Offline + Auth

Installed by AgentX Runner.
