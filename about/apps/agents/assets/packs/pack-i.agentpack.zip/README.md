# Pack I — LLM + AI Utilities

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **Clipboard Manager Agent (Productivity)** (`clipboard-manager-agent-productivity`) — Reads the current clipboard content or writes new content to it. Useful for chaining agents (e.g., "Summarize text" -> "Copy to clipboard").
- **Crypto Wallet Agent (Web3)** (`crypto-wallet-agent-web3`) — Generates a fresh, cryptographically secure Ethereum wallet (Public Address + Private Key) using ethers.js. Can be used for cold storage or dev testing.
- **LLM Client Agent (The "Brain")** (`llm-client-agent-the-brain`) — Connects to a local AI server (like Ollama) or OpenAI to generate text. It attempts to be "smart" by detecting if the local AI is offline and failing gracefully.
- **MIDI Composer Agent (Music)** (`midi-composer-agent-music`) — Generates a random, melodic musical sequence and saves it as a standard .mid file. You can drag this file into GarageBand or Ableton to hear it.
- **Sentiment Analyzer Agent (Emotional Intelligence)** (`sentiment-analyzer-agent-emotional-intelligence`) — Uses a local dictionary-based approach (AFINN-165) to score the emotional tone of text. Runs entirely offline with zero latency.