
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const root = inputs.root;
  const action = inputs.action || "index";
  const artifactsDir = path.join(run.dir, "artifacts");
  const reportPath = path.join(artifactsDir, "filesystem.report.json");

  if(action === "index"){
    const list = tools.fs.list(root);
    const report = { root, files:list, count:list.length };
    tools.fs.writeText(reportPath, JSON.stringify(report, null, 2));
    receipts.addArtifact({ type:"json", path:"artifacts/filesystem.report.json" });
    return report;
  }

  if(action === "rename"){
    const from = inputs.from;
    const to = inputs.to;
    const r = tools.fs.rename(from, to);
    tools.fs.writeText(reportPath, JSON.stringify({ action, ...r }, null, 2));
    receipts.addArtifact({ type:"json", path:"artifacts/filesystem.report.json" });
    return r;
  }

  if(action === "template"){
    const templatePath = inputs.templatePath;
    const outPath = inputs.outPath;
    const vars = inputs.vars ? JSON.parse(inputs.vars) : {};
    let t = tools.fs.readText(templatePath);
    for(const [k,v] of Object.entries(vars)){
      t = t.split(`{{${k}}}`).join(String(v));
    }
    tools.fs.writeText(outPath, t);
    tools.fs.writeText(reportPath, JSON.stringify({ action, templatePath, outPath, keys:Object.keys(vars) }, null, 2));
    receipts.addArtifact({ type:"json", path:"artifacts/filesystem.report.json" });
    return { ok:true, outPath };
  }

  throw new Error(`Unknown action: ${action}`);
};
