
module.exports.run = async function({ inputs, tools, receipts }){
  const cmd = inputs.cmd || "node";
  const args = Array.isArray(inputs.args) ? inputs.args : (inputs.args ? String(inputs.args).split(",").map(s=>s.trim()).filter(Boolean) : []);
  const cwd = inputs.cwd || process.cwd();
  receipts.step({ event:"exec.start", cmd, args, cwd });
  const r = await tools.exec({ cmd, args, cwd, env: {} });
  receipts.step({ event:"exec.done", code:r.code });
  // write artifacts
  const outPath = `${inputs.out || run?.dir || "."}/artifacts/cli.stdout.txt`;
  const errPath = `${inputs.out || run?.dir || "."}/artifacts/cli.stderr.txt`;
  try{ tools.fs.writeText(outPath, r.stdout); receipts.addArtifact({ type:"file", path:"artifacts/cli.stdout.txt" }); }catch{}
  try{ tools.fs.writeText(errPath, r.stderr); receipts.addArtifact({ type:"file", path:"artifacts/cli.stderr.txt" }); }catch{}
  return { code:r.code, stdout:r.stdout.slice(0,4000), stderr:r.stderr.slice(0,4000) };
};
