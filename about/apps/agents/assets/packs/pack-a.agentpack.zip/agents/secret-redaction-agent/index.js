
const path = require("path");

function redactText(tools, s){
  return tools.secrets.redact(s);
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const files = inputs.files ? JSON.parse(inputs.files) : [];
  const outDir = path.join(run.dir, "artifacts", "redacted");
  const report = { scanned:[], written:[] };

  for(const p of files){
    const txt = tools.fs.readText(p);
    const red = redactText(tools, txt);
    const outPath = path.join(outDir, path.basename(p) + ".redacted.txt");
    tools.fs.writeText(outPath, red);
    report.scanned.push(p);
    report.written.push(outPath);
  }
  const reportPath = path.join(run.dir, "artifacts", "redaction.report.json");
  tools.fs.writeText(reportPath, JSON.stringify(report, null, 2));
  receipts.addArtifact({ type:"json", path:"artifacts/redaction.report.json" });
  return report;
};
