
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const targetDir = inputs.targetDir;
  const mode = inputs.mode || "file"; // file | bind
  const pairs = inputs.pairs ? JSON.parse(inputs.pairs) : {};
  const resolved = {};
  for(const [k,v] of Object.entries(pairs)){
    if(typeof v === "string" && v.startsWith("handle:")){
      resolved[k] = tools.secrets.readHandle(v);
    } else {
      resolved[k] = String(v);
    }
  }

  if(mode === "bind"){
    const env = tools.env.bind(resolved);
    receipts.step({ event:"env.bind.done", keys:Object.keys(env) });
    return { ok:true, mode:"bind", keys:Object.keys(env) };
  }

  const envPath = path.join(targetDir, ".env");
  const lines = Object.entries(resolved).map(([k,v]) => `${k}=${v}`);
  tools.fs.writeText(envPath, lines.join("\n") + "\n");
  receipts.addArtifact({ type:"file", path: path.relative(run.dir, envPath) });
  receipts.step({ event:"env.file.written", targetDir, keys:Object.keys(resolved) });
  return { ok:true, mode:"file", envPath, keys:Object.keys(resolved) };
};
