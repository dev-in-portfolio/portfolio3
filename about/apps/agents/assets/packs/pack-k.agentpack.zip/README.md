# Pack K — Security + Compliance

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **Audio Spectrogram Agent (Signal Processing)** (`audio-spectrogram-agent-signal-processing`) — Analyzes an audio file and generates a visual heatmap (Spectrogram) of frequencies over time. Essential for audio engineering and forensics.
- **Blockchain Miner Agent (Crypto)** (`blockchain-miner-agent-crypto`) — Demonstrates the core mechanism of Bitcoin (Proof-of-Work). It tries millions of random "nonces" until it finds a SHA256 hash that starts with a specific number of zeros (difficulty).
- **DNS Digger Agent (Network Intel)** (`dns-digger-agent-network-intel`) — Performs a deep dive into a domain's DNS records, retrieving A, AAAA, MX, TXT, and NS records. Useful for debugging email issues or verification tokens.
- **Exif Metadata Spy (Forensics)** (`exif-metadata-spy-forensics`) — Extracts hidden metadata from images (GPS coordinates, Camera Model, Shutter Speed, Date Taken). Useful for verifying the origin of an image.
- **File Date Spoofer (Forensics)** (`file-date-spoofer-forensics`) — Modifies the "Created", "Modified", and "Accessed" timestamps of a file to any date in the past or future. Used to hide when a file was actually touched.
- **File Encryptor Agent (Security)** (`file-encryptor-agent-security`) — Encrypts (and Decrypts) any file using AES-256-CTR. Protects sensitive documents before sharing or storage.
- **File Integrity Monitor (Compliance)** (`file-integrity-monitor-compliance`) — Calculates SHA-256 hashes of all files in a directory and compares them to a "known good" baseline to detect unauthorized changes (e.g., malware or tampering).
- **JWT Token Generator (Auth Utility)** (`jwt-token-generator-auth-utility`) — Creates valid, cryptographically signed JSON Web Tokens (JWTs) using HMAC SHA256. Useful for testing APIs that require authentication headers without needing a full login flow.
- **Network Port Scanner** (`network-port-scanner`) — Security / Diagnostic tool. It scans a target host (localhost or IP) for open ports to ensure services are running (or to find unauthorized listeners).
- **Password Auditor (Security)** (`password-auditor-security`) — Analyzes a password string for strength, calculates entropy, and estimates the time it would take to crack it via brute force.
- **Ransomware Canary (Defense)** (`ransomware-canary-defense`) — Creates a hidden "honey pot" file and watches it. If any process modifies or deletes this file (typical ransomware behavior), it triggers an alert.
- **Secure File Shredder (Privacy)** (`secure-file-shredder-privacy`) — Permanently destroys a file by overwriting it with 0s, 1s, and random bytes before deleting. Makes forensic recovery nearly impossible.
- **SEO Auditor Agent (Marketing)** (`seo-auditor-agent-marketing`) — Crawls a URL and checks for critical SEO tags (Title, Description, H1, Alt Tags) and performance indicators. Generates a "Scorecard."
- **SSL Certificate Checker (Network Security)** (`ssl-certificate-checker-network-security`) — Connects to a domain via TLS, retrieves the certificate chain, and calculates days until expiration. Essential for uptime monitoring.
- **Subdomain Enumerator (Recon)** (`subdomain-enumerator-recon`) — Uses a dictionary attack to find active subdomains (e.g., admin.site.com, mail.site.com) by resolving them against DNS.
- **Token Counter Agent (Cost Estimator)** (`token-counter-agent-cost-estimator`) — Calculates the number of tokens in a string using gpt-3-encoder. Essential for estimating LLM costs and ensuring prompts fit within context windows.
- **TOTP Authenticator (Security)** (`totp-authenticator-security`) — Generates Time-based One-Time Passwords (like Google Authenticator) for a given 2FA secret. Useful for automating logins that require 2FA.
- **Whois Agent (Network Intel)** (`whois-agent-network-intel`) — Queries WHOIS servers to find domain registration details (Registrar, Creation Date, Expiry). Useful for domain research.