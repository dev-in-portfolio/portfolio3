# Pack F — Data + Docs

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **Code Formatter Agent (Dev Utility)** (`code-formatter-agent-dev-utility`) — formats source code (.js, .json, .css, .md) using prettier. Ensures consistent style across your project files.
- **Contract Filler (Legal Automation)** (`contract-filler-legal-automation`) — Takes a text template (e.g., NDA) with placeholders like {{NAME}} and fills them with provided data. Safe, local document generation.
- **Cron Scheduler Agent** (`cron-scheduler-agent`) — Registers a task in a local JSON schedule registry. This avoids cross-platform issues with system crontab. A hypothetical "Runner" would read this file.
- **CSV Processor Agent (Data Logic)** (`csv-processor-agent-data-logic`) — Reads a raw CSV file, parses it, filters rows based on criteria, and exports the result as JSON. Real data transformation logic.
- **Excel Cleaner (Data Hygiene)** (`excel-cleaner-data-hygiene`) — Reads an Excel file, removes duplicate rows, trims whitespace from cells, and saves a "Clean" version.
- **In-Memory SQL Engine (Database)** (`in-memory-sql-engine-database`) — A tiny SQL parser that runs queries like SELECT name FROM users WHERE age > 20 directly against a JSON array. Shows how database filtering logic works.
- **Invoice Generator Agent (Finance)** (`invoice-generator-agent-finance`) — Generates a professional PDF invoice with line items, totals, and tax calculations using pdfkit.
- **JSON Validator Agent (DevTools)** (`json-validator-agent-devtools`) — Validates a JSON file against basic syntax rules or a provided schema. Finds syntax errors (trailing commas, missing quotes) instantly.
- **License Compliance Agent (Legal)** (`license-compliance-agent-legal`) — Scans a project's node_modules folder (or package.json) to list all software licenses used. Flags "Copyleft" licenses (GPL) that might be risky for proprietary code.
- **Log Analyzer Agent (Analytics Logic)** (`log-analyzer-agent-analytics-logic`) — Parses raw server logs (Apache/Nginx style), aggregates traffic statistics, and identifies error spikes. Uses regex capture groups and statistical sorting.
- **Markdown Table Generator (Productivity)** (`markdown-table-generator-productivity`) — Converts a JSON array or CSV-like string into a perfectly formatted Markdown table. Useful for generating reports or documentation.
- **Markdown to HTML Agent (Content Logic)** (`markdown-to-html-agent-content-logic`) — Converts Markdown documentation into static HTML. Includes a simple regex-based parser (no heavy deps) to show logic implementation.
- **PDF Extractor Agent (Document Intelligence)** (`pdf-extractor-agent-document-intelligence`) — Reads a PDF file and extracts raw text content. Essential for indexing documents, analyzing invoices, or scraping academic papers.
- **Slide Deck Builder (Presentation)** (`slide-deck-builder-presentation`) — Generates a .pptx PowerPoint presentation from a simple JSON structure. Great for automating monthly status reports.
- **SQLite Query Agent** (`sqlite-query-agent`) — Executes SQL queries against a local database file (.db). Great for data seeding, verification, or ad-hoc reporting.
- **Text Adventure Engine (Interactive Fiction)** (`text-adventure-engine-interactive-fiction`) — Loads a JSON "world" definition (rooms, items, exits) and lets the user navigate it via command line. A mini-engine for Interactive Fiction.
- **Text Diff Engine (Algorithms)** (`text-diff-engine-algorithms`) — Compares two text files and outputs the line-by-line differences (Git style) using the diff algorithm. Shows exactly what changed.
- **Tree Visualizer Agent (File Utility)** (`tree-visualizer-agent-file-utility`) — Generates a text-based tree structure of a directory. Useful for documenting project structure or debugging file placement.