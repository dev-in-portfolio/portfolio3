# Pack L — Utility Playground

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **A Pathfinder (AI)**** (`a-pathfinder-ai`) — Finds the shortest path between two points in a grid with obstacles using the A* (A-Star) algorithm. Visualizes the path in ASCII.
- **ARP Network Scanner (Recon)** (`arp-network-scanner-recon`) — Scans the local network cache to identify connected devices (IP and MAC addresses). Useful for finding "who is on my WiFi."
- **Astronomy Agent (Space)** (`astronomy-agent-space`) — Calculates the current phase of the moon and the position of the sun. Can determine sunrise/sunset times for a given latitude/longitude.
- **Brainfuck Interpreter (Esoteric)** (`brainfuck-interpreter-esoteric`) — Runs code written in Brainfuck, a famous minimalistic language that uses only 8 characters (> < + - . , [ ]). Requires manipulating a memory tape byte-by-byte.
- **Currency Converter Agent (Finance)** (`currency-converter-agent-finance`) — Fetches real-time exchange rates (USD base) from a public API and performs conversions.
- **Dice Roller Agent (Randomness)** (`dice-roller-agent-randomness`) — Simulates rolling dice (d6, d20, etc.) using cryptographic randomness. Useful for games or decision making.
- **Disk Space Analyzer (System)** (`disk-space-analyzer-system`) — Scans a directory recursively to calculate total size and identify largest files. Helpful for cleaning up clutter.
- **DNA Translator Agent (Bio-informatics)** (`dna-translator-agent-bio-informatics`) — Translates a raw DNA sequence (e.g., "GATTACA") into its complementary strand, RNA equivalent, and Protein (Amino Acid) sequence.
- **Fake Update Agent (Prank)** (`fake-update-agent-prank`) — Instantly launches a full-screen browser window displaying a realistic "Windows Update" or "macOS Update" animation. Locks the user's attention (until they press F11/Esc).
- **Ghost Typer Agent (Haunted)** (`ghost-typer-agent-haunted`) — Waits a few seconds, then takes control of the keyboard to type a message character by character. Looks exactly like someone has remote control of the PC.
- **Honeyport Agent (Trap)** (`honeyport-agent-trap`) — Opens a fake server on a common port (e.g., 8080 or 21). If anyone tries to connect to it (like a network scanner or hacker), it logs their IP and disconnects them.
- **Hue Light Controller (IoT)** (`hue-light-controller-iot`) — Controls Philips Hue smart lights (or compatible Zigbee bridges). Can toggle power, change brightness, and set RGB colors remotely.
- **Instagram Avatar Grabber (OSINT)** (`instagram-avatar-grabber-osint`) — Fetches the high-resolution profile picture URL for a public Instagram user without needing an API key (using public scraping).
- **Invisible Folder Agent (Magic Vanish)** (`invisible-folder-agent-magic-vanish`) — Toggles the "Hidden" attribute of a folder. On Windows, this makes it disappear from Explorer (unless "Show Hidden" is on). On Mac/Linux, it renames it with a . prefix.
- **Language Detector Agent (Linguistic ID)** (`language-detector-agent-linguistic-id`) — Analyzes a text sample and determines the probability of it being English, Spanish, French, etc. Useful for routing support tickets or selecting translation models.
- **Linear Regression Agent (Data Science)** (`linear-regression-agent-data-science`) — Takes a set of X,Y data points, calculates the "Line of Best Fit" (y = mx + b), and predicts future values. The foundation of Machine Learning.
- **Local Server Agent (Instant Hosting)** (`local-server-agent-instant-hosting`) — Instantly spins up a static HTTP server for a specific directory. Useful for previewing HTML builds or sharing files on the LAN.
- **Loot Box Simulator (Gacha Logic)** (`loot-box-simulator-gacha-logic`) — Simulates opening "Loot Boxes" based on a weighted probability table. Useful for game balancing or demonstrating RNG (Random Number Generation) mechanics.
- **Markov Chain Agent (Text Gen)** (`markov-chain-agent-text-gen`) — Ingests a text source, builds a probabilistic model of word transitions (Markov Chain), and generates new "nonsense" text that mimics the style of the original.
- **Minecraft Server Pinger (Gaming)** (`minecraft-server-pinger-gaming`) — Queries a Minecraft Server (Java Edition) for its status, MOTD (Message of the Day), version, and current player count.
- **Mini-Compiler Agent (Language Design)** (`mini-compiler-agent-language-design`) — A tiny interpreter for a custom language called "ToyScript." It supports variables, printing, and basic math. Shows how code is actually parsed and executed.
- **MQTT Broker Agent (IoT Hub)** (`mqtt-broker-agent-iot-hub`) — Connects to an MQTT broker (like Mosquitto) to publish messages or subscribe to a topic for a few seconds. Essential for debugging IoT sensor networks.
- **Neural Net Trainer (Machine Learning)** (`neural-net-trainer-machine-learning`) — Trains a simple Perceptron (Single-Layer Neural Network) from scratch to solve logic gates (like OR/AND) without using any ML libraries.
- **Physics Engine Agent (Simulation)** (`physics-engine-agent-simulation`) — Simulates simple 2D physics (gravity, bouncing balls) and outputs the frame data. Useful for understanding kinematics or creating animations.
- **Prime Number Checker (Math)** (`prime-number-checker-math`) — Determines if a number is prime and, if not, finds its factors. A classic computational task.
- **Quote of the Day Agent (Inspiration)** (`quote-of-the-day-agent-inspiration`) — Fetches an inspiring quote from a public API. Simple, but great for dashboard "motd" (Message of the Day) widgets.
- **Rhyme Finder Agent (Linguistics)** (`rhyme-finder-agent-linguistics`) — Finds perfect rhymes, near rhymes, and alliteration for a given word using the Datamuse API. Useful for poetry or songwriting.
- **Speedtest Agent (The "Dashboard" Tool)** (`speedtest-agent-the-dashboard-tool`) — Connects to Ookla's Speedtest.net servers to measure Ping, Download, and Upload speeds.
- **Subliminal Message Flasher (Psych Tech)** (`subliminal-message-flasher-psych-tech`) — Uses a transparent, always-on-top Electron window to flash a text message on the user's screen for 10ms every few seconds. Imperceptible but present.
- **Sudoku Solver Agent (Logic)** (`sudoku-solver-agent-logic`) — Solves any Sudoku puzzle instantly using a recursive backtracking algorithm. Useful for demonstrating constraint satisfaction.
- **System Spec Agent (Hardware Info)** (`system-spec-agent-hardware-info`) — Pulls detailed hardware specifications including CPU brand, Cores, RAM speed, Battery level, and OS build. Uses the powerful systeminformation library.
- **Torrent Downloader Agent (P2P)** (`torrent-downloader-agent-p2p`) — Downloads files via the BitTorrent protocol using webtorrent. Supports magnet links.
- **Unit Converter Agent (Utility)** (`unit-converter-agent-utility`) — A robust conversion engine for Length, Weight, Temperature, and Volume.
- **URL Shortener Agent (Utility)** (`url-shortener-agent-utility`) — Uses a public API (TinyURL) to shorten a long URL.
- **USB Watchdog (Hardware)** (`usb-watchdog-hardware`) — Monitors the system for new USB devices plugged in or removed. Uses OS polling to avoid native dependency compilation issues.
- **vCard Generator (Networking)** (`vcard-generator-networking`) — Generates a standard .vcf file for importing contacts into Outlook, iOS, or Android.
- **Wake-on-LAN Agent (IoT Magic)** (`wake-on-lan-agent-iot-magic`) — Sends a "Magic Packet" over the network to a specific MAC address. If the target PC has Wake-on-LAN enabled in BIOS, it will physically turn on.
- **Weather Agent (Real-time Info)** (`weather-agent-real-time-info`) — Fetches current weather data for a city using the Open-Meteo API (Free, no key required).
- **Zip Bomb Generator (The "Trap")** (`zip-bomb-generator-the-trap`) — Creates a "Recursive Zip Bomb" — a tiny file (kilobytes) that expands into massive size (Gigabytes/Petabytes) if extracted.