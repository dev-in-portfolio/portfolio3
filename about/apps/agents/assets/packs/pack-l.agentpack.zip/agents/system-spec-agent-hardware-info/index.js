// Auto-generated stub agent for System Spec Agent (Hardware Info) (system-spec-agent-hardware-info)
// This is a demo pack placeholder. Wire real functionality in your local runner.
module.exports.run = async function run(ctx = {}) {
  const receipts = ctx.receipts || { step: () => {}, artifact: () => {} };
  receipts.step({
    at: new Date().toISOString(),
    agent: "system-spec-agent-hardware-info",
    event: "stub.run",
    note: "This agent is a stub in the demo pack."
  });
  return { ok: true, agent: "system-spec-agent-hardware-info", note: "Stub executed. Replace with real implementation." };
};
