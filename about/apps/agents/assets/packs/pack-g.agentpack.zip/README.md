# Pack G — Media + Visual

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **ASCII Art Agent (Visual)** (`ascii-art-agent-visual`) — Converts standard text into large ASCII art banners using figlet. Great for CLI tool headers or adding flair to logs.
- **Audio Transcriber Agent (Hearing)** (`audio-transcriber-agent-hearing`) — Converts audio files (mp3, wav) into text using the OpenAI Whisper API. Essential for processing voice notes or meeting recordings.
- **Barcode Generator Agent (Utility)** (`barcode-generator-agent-utility`) — Generates retail-standard barcodes (Code 128, EAN, UPC) as PNG images. Useful for inventory tracking or printing labels.
- **Binaural Beat Generator (Audio Synthesis)** (`binaural-beat-generator-audio-synthesis`) — Generates a .wav file with a specific frequency in the Left ear and a slightly different one in the Right ear. The brain perceives the difference (the "beat"). Used for focus (Gamma), relaxation (Alpha), or sleep (Delta).
- **Chart Generator Agent (Data Viz)** (`chart-generator-agent-data-viz`) — Turns raw numbers (JSON) into a professional PNG bar or line chart using chart.js. Perfect for automated reporting.
- **Colorblindness Simulator (Accessibility)** (`colorblindness-simulator-accessibility`) — Processes an image and simulates how it looks to someone with Protanopia (Red-Blind), Deuteranopia (Green-Blind), or Tritanopia (Blue-Blind). Essential for checking UI contrast.
- **Fractal Generator (Chaos Theory)** (`fractal-generator-chaos-theory`) — Renders the Mandelbrot Set (or Julia Set) to a high-resolution PNG image. Demonstrates complex number iteration.
- **Image Processor Agent (Media)** (`image-processor-agent-media`) — Resizes, converts, or grayscales images using jimp (JavaScript Image Manipulation Program). A lightweight alternative to sharp that doesn't require native compilation.
- **Matrix Rain Agent (Visuals)** (`matrix-rain-agent-visuals`) — Turns your terminal into the "Matrix" digital rain code. Purely aesthetic, but a classic computing staple.
- **Meme Generator Agent (Visuals)** (`meme-generator-agent-visuals`) — Takes an image and overlays "Top Text" and "Bottom Text" using the Impact font (classic meme style). Uses jimp for pure JS image editing.
- **Morse Code Audio Agent (Tactical)** (`morse-code-audio-agent-tactical`) — Converts a text string into a standard WAV audio file of Morse Code beeps (dots and dashes).
- **OCR Agent (Computer Vision)** (`ocr-agent-computer-vision`) — Reads text from an image (scanned doc, screenshot, sign) using Tesseract.js. It turns pixels into copy-pasteable strings.
- **Pixel Art Upscaler (Graphics)** (`pixel-art-upscaler-graphics`) — Resizes small pixel art images (e.g., 16x16) to large sizes (e.g., 512x512) using "Nearest Neighbor" interpolation to preserve sharp edges (no blur).
- **QR Code Generator Agent (Media)** (`qr-code-generator-agent-media`) — Generates a QR Code image (PNG) for any given text or URL. Useful for sharing links to mobile devices.
- **Site Mirror Agent (Archivist)** (`site-mirror-agent-archivist`) — Downloads a complete static copy of a website (HTML, CSS, Images) to a local folder. Like wget but in JS. Great for backups or offline viewing.
- **Sprite Slicer Agent (Game Dev)** (`sprite-slicer-agent-game-dev`) — Takes a single "Sprite Sheet" image (grid of characters) and slices it into individual image files based on a fixed grid size (e.g., 32x32).
- **Text-to-Speech Agent (Speaking)** (`text-to-speech-agent-speaking`) — Converts text into a high-quality MP3 audio file using the OpenAI TTS API. Useful for creating announcements, podcast intros, or accessibility features.
- **Video-to-GIF Agent (Media)** (`video-to-gif-agent-media`) — Converts a video file (MP4/MOV) into an animated GIF. It uses ffmpeg to optimize the palette for high quality.
- **Wallpaper Swapper (Redecorator)** (`wallpaper-swapper-redecorator`) — Instantly changes the desktop background to a specified image. Can be used for branding, alerts, or pranks.
- **Watermark Agent (Media)** (`watermark-agent-media`) — Applies a semi-transparent text watermark to an image. Perfect for copyright protection or branding social media content.
- **YouTube Downloader Agent (The "I Need This" Tool)** (`youtube-downloader-agent-the-i-need-this-tool`) — Downloads videos or extracts audio from YouTube URLs using ytdl-core. No ads, no sketchy sites.