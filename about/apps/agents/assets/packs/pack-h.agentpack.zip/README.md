# Pack H — Communication + Scheduling

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **Calendar Invite Agent (Scheduling)** (`calendar-invite-agent-scheduling`) — Generates a standard .ics file for calendar events. Compatible with Outlook, Google Calendar, and Apple Calendar.
- **Desktop Notifier Agent (OS Integration)** (`desktop-notifier-agent-os-integration`) — Triggers a native system notification (Toast on Windows, Banner on Mac, Notification on Linux). Great for "Job Complete" alerts.
- **Discord Webhook Agent (Social)** (`discord-webhook-agent-social`) — Sends a "Rich Embed" (fancy formatted message with colors, fields, and footers) to a Discord channel via Webhook URL. Great for system alerts or status reports.
- **Identicon Generator (Procedural Art)** (`identicon-generator-procedural-art`) — Generates a unique, geometric avatar (Identicon) based on a text string (like an email or username). Consistent input always produces the same unique image.
- **Mouse Jiggler Agent (The "AFK Cheat")** (`mouse-jiggler-agent-the-afk-cheat`) — programmatically moves your mouse cursor 1 pixel every minute. Keeps your computer awake and your Teams/Slack status "Green" (Active) while you nap.
- **Resume Parser Agent (HR Tech)** (`resume-parser-agent-hr-tech`) — Reads a resume (PDF/Text) and attempts to extract structured contact info (Email, Phone) and Keywords (Skills).
- **RSS Monitor Agent (Content Ingestion)** (`rss-monitor-agent-content-ingestion`) — Fetches an RSS feed URL, parses the XML, and extracts the latest headlines. Useful for tracking blogs, system status pages, or news.
- **Slack Bot Agent (Communication)** (`slack-bot-agent-communication`) — Sends a formatted message to a Slack channel via Incoming Webhook (just like the Discord agent, but for Slack's specific JSON structure).
- **SMTP Sender Agent (Communication)** (`smtp-sender-agent-communication`) — Sends an email using an SMTP server (e.g., Gmail, Outlook, or local Mailhog). Useful for alerting, reporting, or testing transactional emails.