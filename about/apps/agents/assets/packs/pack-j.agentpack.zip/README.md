# Pack J — Web QA + Growth

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **Broken Link Crawler (QA / Web)** (`broken-link-crawler-qa-web`) — Spiders a starting URL, extracts all hyperlinks (<a href="...">), and sends HTTP HEAD/GET requests to verify they are accessible (Status 200). Detects dead links ("link rot").
- **HTML Scraper Agent (Lightweight Web)** (`html-scraper-agent-lightweight-web`) — Uses cheerio (jQuery for server-side) to scrape static HTML pages. Faster and more lightweight than Playwright for sites that don't need JavaScript execution.
- **Reddit Scraper (Social)** (`reddit-scraper-social`) — Pulls the top posts from a specific subreddit (title, score, link) and saves them as a structured JSON report. Great for trend monitoring.