
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const baseUrl = inputs.baseUrl || "http://localhost:8888";
  const recordingPath = inputs.recordingPath;
  const rec = JSON.parse(tools.fs.readText(recordingPath));
  const flow = rec.flow || "replay";
  const steps = rec.steps || [];
  const res = await tools.browser.runFlow({ targetKey: rec.targetKey || "demo", baseUrl, flow, steps });
  const shotsDir = path.join(run.dir, "artifacts", "screenshots");
  let i=0;
  for(const s of res.screenshots){
    tools.fs.writeBytes(path.join(shotsDir, `${i++}-${s.label}.png`), s.bytes);
  }
  receipts.step({ event:"replay.done", steps:steps.length });
  return { ok:true, steps:steps.length };
};
