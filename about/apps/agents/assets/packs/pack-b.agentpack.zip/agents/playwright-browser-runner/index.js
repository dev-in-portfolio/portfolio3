
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const baseUrl = inputs.baseUrl || "http://localhost:8888";
  const flow = inputs.flow || "default";
  const steps = inputs.steps ? JSON.parse(inputs.steps) : [
    { action:"goto", url:"/agents/demo-targets/form-lab/" },
    { action:"screenshot", label:"landing" }
  ];

  const res = await tools.browser.runFlow({ targetKey: inputs.targetKey || "demo", baseUrl, flow, steps });
  const shotsDir = path.join(run.dir, "artifacts", "screenshots");
  const saved = [];
  for(const s of res.screenshots){
    const p = path.join(shotsDir, `${s.label}.png`);
    tools.fs.writeBytes(p, s.bytes);
    saved.push(p);
  }
  receipts.addArtifact({ type:"screenshots", count:saved.length, path:"artifacts/screenshots/" });
  return { ok:true, flow, saved };
};
