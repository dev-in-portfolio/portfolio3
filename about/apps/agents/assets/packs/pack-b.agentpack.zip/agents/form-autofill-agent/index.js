
const path = require("path");

module.exports.run = async function({ inputs, tools, receipts, run }){
  const baseUrl = inputs.baseUrl || "http://localhost:8888";
  const targetUrl = inputs.targetUrl || "/agents/demo-targets/form-lab/";
  const data = inputs.data ? JSON.parse(inputs.data) : { name:"Devin", email:"dev@example.com" };

  // preview-first: fill fields then screenshot
  const steps = [
    { action:"goto", url: targetUrl },
    { action:"fill", selector:'input[name="name"]', value: data.name || "" },
    { action:"fill", selector:'input[name="email"]', value: data.email || "" },
    { action:"screenshot", label:"preview" }
  ];

  const res = await tools.browser.runFlow({ targetKey:"demo-form-lab", baseUrl, flow:"autofill.preview", steps });
  const shotsDir = path.join(run.dir, "artifacts", "screenshots");
  for(const s of res.screenshots){
    tools.fs.writeBytes(path.join(shotsDir, `${s.label}.png`), s.bytes);
  }
  receipts.step({ event:"autofill.preview.done" });

  // approve-before-submit
  tools.approval.require({ level:"medium", proofLabel:"form-submit" });
  const approved = String(inputs.approve || "").toLowerCase() === "true";
  if(!approved){
    receipts.step({ event:"submit.skipped", reason:"approval.required" });
    return { ok:true, submitted:false, note:"Set --approve true to allow submit in demo." };
  }

  // submit (demo only)
  const steps2 = [
    { action:"goto", url: targetUrl },
    { action:"fill", selector:'input[name="name"]', value: data.name || "" },
    { action:"fill", selector:'input[name="email"]', value: data.email || "" },
    { action:"click", selector:'button[type="submit"]' },
    { action:"wait", ms: 250 },
    { action:"screenshot", label:"submitted" }
  ];
  const res2 = await tools.browser.runFlow({ targetKey:"demo-form-lab", baseUrl, flow:"autofill.submit", steps: steps2 });
  for(const s of res2.screenshots){
    tools.fs.writeBytes(path.join(shotsDir, `${s.label}.png`), s.bytes);
  }
  receipts.step({ event:"submit.done" });
  return { ok:true, submitted:true };
};
