
const path = require("path");
const { PNG } = require("pngjs");
const pixelmatch = require("pixelmatch");

function diffPng(aBuf, bBuf){
  const a = PNG.sync.read(aBuf);
  const b = PNG.sync.read(bBuf);
  const { width, height } = a;
  const diff = new PNG({ width, height });
  const mismatched = pixelmatch(a.data, b.data, diff.data, width, height, { threshold: 0.1 });
  return { mismatched, diffBuf: PNG.sync.write(diff) };
}

module.exports.run = async function({ inputs, tools, receipts, run }){
  const baseUrl = inputs.baseUrl || "http://localhost:8888";
  const targetUrl = inputs.targetUrl || "/agents/demo-targets/job-board/";
  const baselinePath = inputs.baselinePath; // png
  const steps = [
    { action:"goto", url: targetUrl },
    { action:"wait", ms: 200 },
    { action:"screenshot", label:"current" }
  ];
  const res = await tools.browser.runFlow({ targetKey:"demo", baseUrl, flow:"regression", steps });
  const curBuf = res.screenshots[0].bytes;

  const baselineBuf = tools.fs.readBytes(baselinePath);
  const { mismatched, diffBuf } = diffPng(baselineBuf, curBuf);

  const outDir = path.join(run.dir, "artifacts", "diff");
  tools.fs.writeBytes(path.join(outDir, "current.png"), curBuf);
  tools.fs.writeBytes(path.join(outDir, "diff.png"), diffBuf);

  const report = { mismatchedPixels: mismatched, threshold: 0 };
  tools.fs.writeText(path.join(outDir, "diff.report.json"), JSON.stringify(report, null, 2));
  receipts.addArtifact({ type:"diff", path:"artifacts/diff/" });
  return { ok:true, ...report };
};
