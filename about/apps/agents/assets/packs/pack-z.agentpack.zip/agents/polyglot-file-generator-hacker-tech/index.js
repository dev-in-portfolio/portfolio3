// NOT ENABLED stub for Polyglot File Generator (Hacker Tech) (polyglot-file-generator-hacker-tech)
// This pack is intentionally non-runnable in demo builds.
// No surveillance/evasion tooling is shipped.
module.exports.run = async function run(ctx = {}) {
  const receipts = ctx.receipts || { step: () => {}, artifact: () => {} };
  receipts.step({
    at: new Date().toISOString(),
    agent: "polyglot-file-generator-hacker-tech",
    level: "BLOCKED",
    msg: "This agent is not enabled. Demo pack contains stubs only."
  });
  return {
    ok: false,
    blocked: true,
    reason: "NOT_ENABLED",
    message: "This agent is intentionally disabled. Download is a transparency stub only."
  };
};
