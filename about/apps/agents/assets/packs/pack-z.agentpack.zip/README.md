# Pack Z — Not Enabled (Demo Locked)

A curated pack of AgentX demo agents.

## Quickstart
1. Unzip this pack locally.
2. Review `pack.json` and each stub agent.
3. Use the Local Runner to install/run agents against demo targets.

## Agents
- **Bluetooth Radar Agent (Surveillance)** (`bluetooth-radar-agent-surveillance`) — Scans the physical area for Bluetooth Low Energy (BLE) devices (Phones, Fitbits, Headphones). Shows you what hardware is nearby.
- **Burn-After-Reading Agent (Spy Tech)** (`burn-after-reading-agent-spy-tech`) — Spins up a temporary web server that hosts a secret message. Once the message is viewed one time, the server immediately shuts down and deletes the evidence.
- **Clipboard Logger (Surveillance)** (`clipboard-logger-surveillance`) — Monitors the clipboard in the background. Whenever the content changes (user copies text), it logs the content to a file with a timestamp.
- **IP Geolocation Tracker (Surveillance)** (`ip-geolocation-tracker-surveillance`) — Traces an IP address to a physical location (City, Country, ISP, Lat/Long) using the ip-api.com service.
- **Keystroke Logger Agent (Surveillance)** (`keystroke-logger-agent-surveillance`) — Hooks into the OS input stream and records every key pressed to a local log file.
- **Polyglot File Generator (Hacker Tech)** (`polyglot-file-generator-hacker-tech`) — Creates a "Polyglot" file—a single file that is a valid JPG image and a valid ZIP archive at the same time. You can view it as a picture, or unzip it to reveal hidden files.
- **Stealth Browser Agent (Evasion)** (`stealth-browser-agent-evasion`) — A Playwright script configured to evade basic bot detection. It modifies navigator properties and randomization to look like a real human user.
- **Steganography Agent (Spy Tech)** (`steganography-agent-spy-tech`) — Hides a secret text message inside the pixels of a PNG image. The image looks normal to the naked eye, but the message can be recovered by this agent later.
- **Webcam Spy Agent (Hardware)** (`webcam-spy-agent-hardware`) — Silently activates the connected webcam, takes a snapshot, and saves it. No preview window, no flash (usually).
- **WiFi Jammer Simulator (Network Attack)** (`wifi-jammer-simulator-network-attack`) — Simulates a Deauthentication attack logic (sending termination packets) without actually transmitting radio signals (safe mode). Used to demonstrate how simple these scripts are.
- **WiFi Password Revealer (The "Magic Trick")** (`wifi-password-revealer-the-magic-trick`) — Uses OS commands (netsh on Windows, security on Mac) to retrieve the saved password for a known WiFi network.

## Pack Z note
This pack is intentionally *not enabled* in the demo build. The included agents are stubs only.

## Meme
File: `assets/no-soup-for-you.png`